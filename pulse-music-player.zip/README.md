# PULSE — Music Player

A responsive, vanilla HTML/CSS/JavaScript music player built from the supplied task requirements.

## Features

- Modern responsive interface for desktop and mobile
- Upload multiple local audio files
- Play / pause / next / previous
- Song title, artist, duration
- Seekable progress bar with live playback time
- Volume slider and mute
- Shuffle
- Repeat: off / all / one
- Favorites view
- Playlist section placeholder ready for persistence/backend integration
- Autoplay toggle
- Light/dark theme
- Drag-and-drop audio files
- No build step or dependencies required

## Run

Open `index.html` in a modern browser.

For the smoothest browser behavior, serve the folder from a local HTTP server, e.g.:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## File naming

For automatic metadata-like display, use:

`Artist - Song Title.mp3`

Otherwise the filename becomes the song title and the artist is shown as `Local file`.

## Notes

Browsers generally cannot read embedded ID3 artwork/metadata consistently without an additional metadata parser. The current version therefore uses the filename for title/artist and a generated cover style. A production version could add ID3 parsing, IndexedDB persistence, playlists, and media-session integration.
