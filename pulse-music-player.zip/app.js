const audio = document.querySelector("#audio");
const fileInput = document.querySelector("#fileInput");
const songList = document.querySelector("#songList");
const emptyState = document.querySelector("#emptyState");
const progress = document.querySelector("#progress");
const volume = document.querySelector("#volume");

let tracks = [];
let currentIndex = -1;
let shuffle = false;
let repeat = "off"; // off | all | one
let view = "all";
let dragDepth = 0;

const $ = id => document.getElementById(id);
const formatTime = s => {
  if (!Number.isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60).toString().padStart(2, "0");
  return `${m}:${sec}`;
};
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function parseName(fileName) {
  const base = fileName.replace(/\.[^/.]+$/, "");
  const parts = base.split(" - ");
  return parts.length > 1
    ? { artist: parts[0].trim(), title: parts.slice(1).join(" - ").trim() }
    : { artist: "Local file", title: base };
}

function addFiles(files) {
  [...files].filter(f => f.type.startsWith("audio/")).forEach(file => {
    const {artist, title} = parseName(file.name);
    tracks.push({
      id: crypto.randomUUID(),
      file,
      url: URL.createObjectURL(file),
      title,
      artist,
      duration: 0,
      favorite: false
    });
  });
  if (currentIndex < 0 && tracks.length) loadTrack(0, false);
  render();
}

fileInput.addEventListener("change", e => addFiles(e.target.files));

["dragenter","dragover"].forEach(type => document.addEventListener(type, e => {
  e.preventDefault(); dragDepth++;
  document.body.classList.add("dragging");
}));
["dragleave","drop"].forEach(type => document.addEventListener(type, e => {
  e.preventDefault(); dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) document.body.classList.remove("dragging");
}));
document.addEventListener("drop", e => addFiles(e.dataTransfer.files));

function visibleTracks() {
  if (view === "favorites") return tracks.filter(t => t.favorite);
  return tracks;
}

function render() {
  const visible = visibleTracks();
  $("viewTitle").textContent = view === "favorites" ? "Favorites" : view === "playlists" ? "Playlists" : "All Songs";
  $("sectionTitle").textContent = view === "playlists" ? "Playlists" : view === "favorites" ? "Favorite songs" : "Songs";
  $("clearBtn").style.display = view === "playlists" ? "none" : tracks.length ? "block" : "none";

  if (view === "playlists") {
    songList.innerHTML = `<div class="empty-state"><div class="empty-icon">☷</div><h3>Playlist-ready</h3><p>Use the player controls to enjoy your local library. Playlist persistence can be added with a backend or IndexedDB.</p></div>`;
    emptyState.style.display = "none";
    return;
  }

  emptyState.style.display = visible.length ? "none" : "block";
  songList.innerHTML = visible.map(t => {
    const idx = tracks.indexOf(t);
    return `<article class="song ${idx === currentIndex ? "playing" : ""}" data-index="${idx}">
      <div class="thumb">♪</div>
      <div>
        <div class="song-title">${esc(t.title)}</div>
        <div class="song-sub">${esc(t.artist)}</div>
      </div>
      <span class="song-time">${formatTime(t.duration)}</span>
      <button class="mini-fav ${t.favorite ? "on" : ""}" data-fav="${idx}" title="Favorite">${t.favorite ? "♥" : "♡"}</button>
    </article>`;
  }).join("");

  songList.querySelectorAll(".song").forEach(row => row.addEventListener("click", e => {
    if (e.target.closest("[data-fav]")) return;
    loadTrack(Number(row.dataset.index), true);
  }));
  songList.querySelectorAll("[data-fav]").forEach(btn => btn.addEventListener("click", e => {
    e.stopPropagation();
    tracks[Number(btn.dataset.fav)].favorite = !tracks[Number(btn.dataset.fav)].favorite;
    updateFavorite();
    render();
  }));
}

function loadTrack(index, autoplay = true) {
  if (!tracks[index]) return;
  currentIndex = index;
  const t = tracks[index];
  audio.src = t.url;
  audio.load();
  $("trackTitle").textContent = t.title;
  $("trackArtist").textContent = t.artist;
  $("heroTitle").textContent = t.title;
  $("heroArtist").textContent = t.artist;
  updateFavorite();
  render();
  if (autoplay) audio.play().catch(() => {});
}

function updateFavorite() {
  const on = currentIndex >= 0 && tracks[currentIndex]?.favorite;
  $("favoriteBtn").textContent = on ? "♥" : "♡";
  $("favoriteBtn").classList.toggle("on", !!on);
}

function nextIndex(direction = 1) {
  const list = visibleTracks();
  if (!list.length) return -1;
  const current = list.findIndex(t => tracks.indexOf(t) === currentIndex);
  if (shuffle && list.length > 1) {
    let n = current;
    while (n === current) n = Math.floor(Math.random() * list.length);
    return tracks.indexOf(list[n]);
  }
  let n = current + direction;
  if (n >= list.length) n = repeat === "all" ? 0 : -1;
  if (n < 0) n = repeat === "all" ? list.length - 1 : -1;
  return n < 0 ? -1 : tracks.indexOf(list[n]);
}

$("playBtn").addEventListener("click", () => {
  if (!audio.src) { if (tracks.length) loadTrack(0, true); return; }
  audio.paused ? audio.play() : audio.pause();
});
$("prevBtn").addEventListener("click", () => {
  if (audio.currentTime > 3) { audio.currentTime = 0; return; }
  const n = nextIndex(-1); if (n >= 0) loadTrack(n, true);
});
$("nextBtn").addEventListener("click", () => {
  const n = nextIndex(1); if (n >= 0) loadTrack(n, true);
});
$("favoriteBtn").addEventListener("click", () => {
  if (currentIndex < 0) return;
  tracks[currentIndex].favorite = !tracks[currentIndex].favorite;
  updateFavorite(); render();
});
function setShuffle() {
  shuffle = !shuffle;
  [$("shuffleBtn"), $("shuffleTop")].forEach(b => b.classList.toggle("on", shuffle));
}
$("shuffleBtn").addEventListener("click", setShuffle);
$("shuffleTop").addEventListener("click", setShuffle);
$("repeatBtn").addEventListener("click", () => {
  repeat = repeat === "off" ? "all" : repeat === "all" ? "one" : "off";
  $("repeatBtn").textContent = repeat === "one" ? "↻¹" : "↻";
  $("repeatBtn").classList.toggle("on", repeat !== "off");
});
$("muteBtn").addEventListener("click", () => {
  audio.muted = !audio.muted;
  $("muteBtn").textContent = audio.muted ? "🔇" : "🔊";
});
volume.addEventListener("input", () => audio.volume = Number(volume.value));
audio.volume = Number(volume.value);
progress.addEventListener("input", () => {
  if (audio.duration) audio.currentTime = (Number(progress.value) / 100) * audio.duration;
});
audio.addEventListener("loadedmetadata", () => {
  if (tracks[currentIndex]) { tracks[currentIndex].duration = audio.duration; render(); }
  $("duration").textContent = formatTime(audio.duration);
});
audio.addEventListener("timeupdate", () => {
  $("currentTime").textContent = formatTime(audio.currentTime);
  progress.value = audio.duration ? (audio.currentTime / audio.duration) * 100 : 0;
});
audio.addEventListener("play", () => $("playBtn").textContent = "❚❚");
audio.addEventListener("pause", () => $("playBtn").textContent = "▶");
audio.addEventListener("ended", () => {
  if (repeat === "one") { audio.currentTime = 0; audio.play(); return; }
  const n = nextIndex(1);
  if (n >= 0) loadTrack(n, true);
  else if ($("autoplay").checked) audio.play().catch(() => {});
});

document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  view = btn.dataset.view;
  render();
}));
$("clearBtn").addEventListener("click", () => {
  if (!confirm("Remove all local tracks from this session?")) return;
  tracks.forEach(t => URL.revokeObjectURL(t.url));
  tracks = []; currentIndex = -1; audio.removeAttribute("src"); audio.load();
  $("trackTitle").textContent = "Nothing playing";
  $("trackArtist").textContent = "—";
  $("heroTitle").textContent = "Nothing playing";
  $("heroArtist").textContent = "Add an audio file to get started.";
  render();
});
$("themeBtn").addEventListener("click", () => document.body.classList.toggle("dark"));

render();
